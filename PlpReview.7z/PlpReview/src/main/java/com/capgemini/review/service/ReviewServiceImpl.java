package com.capgemini.review.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.review.bean.Review;
import com.capgemini.review.dao.ReviewRepository;
import com.capgemini.review.exception.ReviewException;



@Service
public class ReviewServiceImpl implements ReviewService {

	
	@Autowired
	private ReviewRepository reviewDao;
	@Override
	public List<Review> getAllReviews() throws ReviewException {
		return reviewDao.findAll();
	}

	@Override
	public List<Review> addReview(Review review) throws ReviewException {
		reviewDao.save(review);
		return getAllReviews();
	}

	@Override
	public List<Review> deleteReview(int Id) throws ReviewException {
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review) throws ReviewException {
		reviewDao.save(review);
		return getAllReviews();
	}



}
