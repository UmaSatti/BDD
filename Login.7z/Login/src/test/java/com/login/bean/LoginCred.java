package com.login.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class LoginCred {
	 WebDriver driver;
	 
	    @FindBy(how = How.NAME, name = "title")
	    private WebElement title;
	 
	    @FindBy(how = How.NAME, name = "userName")
	    private WebElement userName;
	 
	    @FindBy(how = How.NAME, name = "userPwd")
	    private WebElement userPwd;
	    
	    @FindBy(how = How.NAME, name = "login")
	    private WebElement submit;
	    
	 
	    
	    public LoginCred(WebDriver driver) {
	        super();
	        this.driver = driver;
	    }
	 
	    public String getTitle() {
	        return new Select(this.title).getFirstSelectedOption().getText();
	    }
	    public void setTitle(String title) {
	        Select select = new Select(this.title);
	        select.selectByVisibleText(title);
	    }
	    public String getUserPwd() {
	        return userPwd.getAttribute("value");
	    }
	 
	    public void setUserPwd(String userName) {
	        this.userPwd.clear();
	        this.userPwd.sendKeys(userName);
	    }
	    
	    public String getUserName() {
	        return userName.getAttribute("value");
	    }
	 
	    public void setUserName(String userName) {
	        this.userName.clear();
	        this.userName.sendKeys(userName);
	    }
	    
	    public void submit() {
			this.submit.click();
		}
}
