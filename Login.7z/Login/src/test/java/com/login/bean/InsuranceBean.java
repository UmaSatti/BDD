package com.login.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class InsuranceBean {
	 WebDriver driver;

	 

	    @FindBy(name = "txtFN")
	    @CacheLookup
	    WebElement firstName;

	 

	    @FindBy(name = "txtLN")
	    @CacheLookup
	    WebElement lastName;

	 

	    @FindBy(how = How.ID, using = "txtEmail")
	    @CacheLookup
	    WebElement email;

	 

	    @FindBy(name = "Phone")
	    @CacheLookup
	    WebElement mobile;

	 

	    @FindBy(name = "AADHAR")
	    @CacheLookup
	    WebElement Aadhar;
	    
	    @FindBy(name = "Address")
	    @CacheLookup
	    WebElement Address;

	 

	    @FindBy(name = "city")
	    @CacheLookup
	    WebElement city;

	 

	    @FindBy(name = "state")
	    @CacheLookup
	    WebElement state;

	 

	    @FindBy(how = How.NAME, name = "Submit")
	    @CacheLookup
	    WebElement submitButton;
	    
	    public InsuranceBean(WebDriver driver) {
	        super();
	        this.driver = driver;
	    }
	    public WebDriver getDriver() {
	        
	        return driver;
	    }

	 

	    public void setDriver(WebDriver driver) {
	        this.driver = driver;
	    }

	 

	    public WebElement getFirstName() {
	        return firstName;
	    }

	 

	    public void setFirstName(String firstName) {
	        
	        this.firstName.sendKeys(firstName);
	    }

	 

	    public WebElement getLastName() {
	        return lastName;
	    }

	 

	    public void setLastName(String lastName) {
	        
	        this.lastName.sendKeys(lastName);
	    }

	 

	    public WebElement getEmail() {
	        return email;
	    }

	 

	    public void setEmail(String email) {
	        
	        this.email.sendKeys(email);
	    }

	 

	    public WebElement getMobile() {
	        return mobile;
	    }

	 

	    public void setMobile(String mobile) {
	        this.mobile.clear();
	        this.mobile.sendKeys(mobile);
	    }

	 

	    public WebElement getAddress() {
	        return Address;
	    }
	    public void setAddress(String address) {
	        this.Address.clear();
	        this.Address.sendKeys(address);
	    }
	    public WebElement getAadhar() {
	        return Aadhar;
	    }

	 

	    public void setAadhar(String aadhar) {
	        this.Aadhar.clear();
	        this.Aadhar.sendKeys(aadhar);
	    }

	 

	    public String getCity() {
	    	return new Select(this.city).getFirstSelectedOption().getText();
	    }

	 

	    public void setCity(String city) {
	    	Select select = new Select(this.city);
			select.selectByVisibleText(city);
	    }

	 

	    public String getState() {
	    	return new Select(this.state).getFirstSelectedOption().getText();
	    }

	 

	    public void setState(String state) {
	    	Select select = new Select(this.state);
			select.selectByVisibleText(state);
	    }

	 

	    public void clickSubmit() {
	        this.submitButton.click();;
	    }
}
