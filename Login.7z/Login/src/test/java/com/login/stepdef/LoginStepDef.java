package com.login.stepdef;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.login.bean.InsuranceBean;
import com.login.bean.LoginCred;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {
	
	private WebDriver driver;
	private LoginCred cred;
	private InsuranceBean insur;
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nurathod\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
		driver.get("C:\\BDD512\\Login\\Login\\li.html");
		cred = PageFactory.initElements(driver, LoginCred.class);
		driver.manage().window().maximize();
	}

	@Given("^\"([^\"]*)\" is the title of the page$")
	public void is_the_title_of_the_page(String expectedTitle) throws Throwable {
		String actualTitle = driver.getTitle();
		
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user is trying to submit data without entering userName$")
	public void user_is_trying_to_submit_data_without_entering_userName() throws Throwable {
	    
	}

	@Then("^'Please enter userName\\.' alert message should be displayed$")
	public void please_enter_userName_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^user is trying to submit data without entering password$")
	public void user_is_trying_to_submit_data_without_entering_password() throws Throwable {
	    
	}

	@Then("^'Please enter password\\.' alert message should be displayed$")
	public void please_enter_password_alert_message_should_be_displayed() throws Throwable {
	    
	}

	@When("^user is trying to submit data without with wrong credentials$")
	public void user_is_trying_to_submit_data_without_with_wrong_credentials() throws Throwable {
	    
	}

	@Then("^'Invalid login! Please try again!' alert message should be displayed$")
	public void invalid_login_Please_try_again_alert_message_should_be_displayed() throws Throwable {
	    
	}

	@When("^user is trying to submit data with credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_is_trying_to_submit_data_with_credentials_and(String arg1, String arg2) throws Throwable {
	    cred.setUserName("lifeinsu");
	    cred.setUserPwd("rance1234");
	    cred.submit();
	    Thread.sleep(1000);
	}

	@Then("^'logedIn' alert message should be displayed$")
	public void logedin_alert_message_should_be_displayed() throws Throwable {
		
		Thread.sleep(1000);
		if (driver.switchTo().alert().getText().equals("logedIn")) {
			driver.switchTo().alert().accept();
		}
	}


	@When("^user enters valid enquiry details$")
	public void user_enters_valid_enquiry_details() throws Throwable {
		driver.get("C:\\BDD512\\Login\\Login\\li1.html");
		insur = PageFactory.initElements(driver, InsuranceBean.class);
		driver.manage().window().maximize();
		insur.setFirstName("sgbrs");
	    insur.setLastName("rrsdbdfb");
	    insur.setEmail("jahve");
	    insur.setMobile("drhbdthb");
		insur.setAadhar("7894561230123");
	    insur.setAddress("jksheabcvfked");
	    insur.setCity("Pune");
	    insur.setState("Maharashtra");
	    insur.clickSubmit();
	}

	@Then("^Verify the message \"([^\"]*)\"$")
	public void verify_the_message(String arg1) throws Throwable {
		Thread.sleep(1000);
		if (driver.switchTo().alert().getText().equals(arg1)) {
			driver.switchTo().alert().accept();
		}
	}
	
	@After
	public void tearDown() throws Exception {
		Thread.sleep(2000);
		
		driver.quit();
	}


}
