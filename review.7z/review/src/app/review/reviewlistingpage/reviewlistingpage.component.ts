import { Component, OnInit } from '@angular/core';
import { Review } from '../bean/review';
import { ReviewService } from '../service/review.service';

@Component({
  selector: 'app-reviewlistingpage',
  templateUrl: './reviewlistingpage.component.html',
  styleUrls: ['./reviewlistingpage.component.css']
})
export class ReviewlistingpageComponent implements OnInit {
  reviews:Review[];
  constructor(private reviewService:ReviewService) { }
  
  ngOnInit() {
  this.reviewService.getAllReviews().subscribe((data)=>{this.reviews=data;});
  
  }
  deleteReview(review:Review){
  this.reviewService.deleteReview(review).subscribe(
  (data)=>{this.reviews=this.reviews.filter(c=>c!==review)}
  );
  }
  }

