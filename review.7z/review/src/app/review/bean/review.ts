export class Review {
    index:number;
    id:number;
    book:String;
    rating:number;
    headline:String;
    customer:String;
    reviewOn:String;
    constructor(book:String,rating:number,headline:String,reviewOn:String){
        this.book=book;
        this.rating=rating;
        this.headline=headline;
        this.reviewOn=reviewOn;
        
    }
}
