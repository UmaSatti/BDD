import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Review } from '../bean/review';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ReviewService {
   userUrl: string= 'http://localhost:4000/';
  reviewData:Review;
  review: Review[];
  private id;
  constructor(private http: HttpClient) { }
  public getAllReviews() {
    return this.http.get<Review[]>(this.userUrl+'/reviews');
  }
   editReview(review:Review){
     return this.http.put(this.userUrl+"/"+review.id,review);
   }
   deleteReview(review:Review){
    return this.http.delete<Review[]>(this.userUrl+"/"+review.id);
   }
  }
