import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditComponent } from './review/edit/edit.component';
import { DeleteComponent } from './review/delete/delete.component';
import { WelcomeComponent } from './review/welcome/welcome.component';
import { ReviewlistingpageComponent } from './review/reviewlistingpage/reviewlistingpage.component';


const routes: Routes = [{path : '', component : WelcomeComponent},
{path : 'review', component : ReviewlistingpageComponent},
  { path: 'edit', component: EditComponent },
{path : 'delete', component : DeleteComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
